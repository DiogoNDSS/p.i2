const fs = require('fs');
const bodyParser = require('body-parser');
const urlencodedParser = bodyParser.urlencoded({ extended: true });
const express = require('express');
const app = express();

const admin = require('./firebase');
const db = admin.database();



function criarTabela(dados) {
    let tabela = `<table class="table table-striped zebrado">
                    <thead>
                        <tr>
                            
                            <th>Nome:</th>
                            <th>Telefone</th>
                            <th>Gênero</th>
                            <th>Endereço</th>
                            <th></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>`;
    for (let chave in dados) {
        tabela += `<tr>
                        <td>${dados[chave].nome}</td>
                        <td>${'*'.repeat(dados[chave].telefone.length)}</td>
                        <td>${dados[chave].genero}</td>
                        <td>${dados[chave].endereço}</td>
                        <td>
                            <a class="btn btn-outline-warning" href="/professores/editar/${chave}">Alterar</a>
                        </td>
                        <td>
                            <a class="btn btn-outline-danger" href="/professores/excluir/${chave}">Excluir</a>
                        </td>
                    </tr>`;
    }            
    tabela += `</tbody >
            </table > `;
    return tabela;
}



// Rota da página que exibe os livros registrados no banco de dados
app.get('/', (req, res) => {
    fs.readFile('src/cabecalho.html', (e, cabecalho) => {
        fs.readFile('src/rodape.html', (e, rodape) => {
            fs.readFile('src/professores/professor.html', (e, dados) => {
                let tabela = "";
                let mensagem = "";
                const docProfessor = db.ref("professores");
                docProfessor.once("value", function(snapshot){
                    tabela = criarTabela(snapshot.val());
                    dados = dados.toString().replace("{tabela}", tabela);
                    if (req.query.acao){
                        let acao = req.query.acao;
                        if (req.query.status){
                            let status = req.query.status;
                            if (acao == "inserir" && status == "true")
                                mensagem = "Professor adicionado com sucesso!";
                            else if (acao == "inserir" && status == "false")
                                mensagem = "Erro ao adicionar Professor!";
                            else if (acao == "editar" && status == "true")
                                mensagem = "Professor editado com sucesso!";
                            else if (acao == "editar" && status == "false")
                                mensagem = "Erro ao editar o Professor!";
                            else if (acao == "excluir" && status == "true")
                                mensagem = "Professor removido com sucesso!";
                            else if (acao == "excluir" && status == "false")
                                mensagem = "Erro ao remover Professor!";
                        }
                    }   
                    dados = dados.toString().replace("{mensagem}", mensagem);  
                    res.writeHead(200, {'Content-Type': 'text/html'});
                    res.write(cabecalho + dados + rodape);
                    res.end();
                });
            });
        });
    });
});

// Rota da página para abrir formulário para inserir um novo registro de livro
app.get('/novo', (req, res) => {
    fs.readFile('src/cabecalho.html', (e, cabecalho) => {
        fs.readFile('src/rodape.html', (e, rodape) => {
            fs.readFile('src/professores/add_professor.html', (e, dados) => {
                res.writeHead(200, {'Content-Type': 'text/html'});
                res.write(cabecalho + dados + rodape);
                res.end();
            });
        });
    });
});

// Rota da página inserir um novo registro de livro
app.post('/novo', urlencodedParser, (req, res) => {
    try{
        const docProfessor = db.ref("professores").push();
        const professor = {
            nome: req.body.nome,
            telefone: req.body.telefone,
            genero: req.body.genero,
            endereço: req.body.endereço
        };
        docProfessor.set(professor);
        res.redirect('/professores/?acao=inserir&status=true');
    }catch(e){
        console.log(e);
        res.redirect('/professores/?acao=inserir&status=false');
    }
});

// Rota da página para abrir formluário para editar os dados de um registro de livro
app.get('/editar/:mat', (req, res) => {
    fs.readFile('src/cabecalho.html', (e, cabecalho) => {
        fs.readFile('src/rodape.html', (e, rodape) => {
            fs.readFile('src/professores/editar_professor.html', (e, dados) => {
                let mat = req.params.mat;
                const docProfessor = db.ref("professores/"+mat);
                docProfessor.once("value", function(snapshot){
                    let nome = snapshot.val().nome;
                    let genero = snapshot.val().genero;
                    let telefone = snapshot.val().telefone;
                    let endereço = snapshot.val().endereço;
                    dados = dados.toString().replace("{nome}", nome);
                    dados = dados.toString().replace("{genero}", genero);
                    dados = dados.toString().replace("{telefone}", telefone);
                    dados = dados.toString().replace("{endereço}", endereço);
                    dados = dados.toString().replace("{mat}", mat);
                    res.writeHead(200, {'Content-Type': 'text/html'});
                    res.write(cabecalho + dados + rodape);
                    res.end();
            });
                
            });
        });
    });
});

// Rota da página para editar os dados de um registro de livro
app.post('/editar', urlencodedParser, (req, res) => {
    try{
    let mat = req.body.mat;
                let nome = req.body.nome;
                let genero = req.body.genero;
                let telefone = req.body.telefone;
                let endereço = req.body.endereço;
                let docProfessor = db.ref("professores");
                docProfessor.child(mat).update(
                    {
                    'nome' : nome,
                    'genero': genero,
                    'telefone': telefone,
                    'endereço': endereço
                    }
                );
                res.redirect("/professores/?acao=editar&status=true");
                } catch(e){
                console.log(e);
                res.redirect("/professores/?acao=editar&status=false");
                }
            });

// Rota da página para abrir formulário para excluir um registro de um livro
app.get('/excluir/:mat', (req, res) => {
    fs.readFile('src/cabecalho.html', (e, cabecalho) => {
        fs.readFile('src/rodape.html', (e, rodape) => {
            fs.readFile('src/professores/remover_professor.html', (e, dados) => {
                let mat = req.params.mat;
                const docProfessor = db.ref("professores/"+mat);
                docProfessor.once("value", function(snapshot){
                    let nome = snapshot.val().nome;
                    let genero = snapshot.val().genero;
                    let telefone = snapshot.val().telefone;
                    let endereço = snapshot.val().endereço;
                    dados = dados.toString().replace("{nome}", nome);
                    dados = dados.toString().replace("{genero}", genero);
                    dados = dados.toString().replace("{telefone}", telefone);
                    dados = dados.toString().replace("{endereço}", endereço);
                    dados = dados.toString().replace("{mat}", mat);
                    res.writeHead(200, {'Content-Type': 'text/html'});
                    res.write(cabecalho + dados + rodape);
                    res.end();
            });
            });
        });
    });
});

// Rota da página para excluir um registro de um livro
app.post('/excluir', urlencodedParser, (req, res) => {
    try{
    let mat = req.body.mat;
    const docProfessor = db.ref("professores/"+mat);
    docProfessor.remove();
    res.redirect("/professores/?acao=excluir&status=true");
} catch(e){
    console.log(e);
    res.redirect("/professores/?acao=excluir&status=false")
}        
});
        

module.exports = app;